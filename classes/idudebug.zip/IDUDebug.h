//
//  IDUDebug.h
//  IDUDebug
//
//  Created by idu on 2017/5/27.
//  Copyright © 2017年 idu. All rights reserved.
//

#import <UIKit/UIKit.h>
#define IDUDebugOpen 1
@interface IDUDebug : UIView

@end
